package VisualDatabase;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Screen;
import javafx.stage.Stage;
import org.controlsfx.control.CheckListView;

public class Visualizer extends Application {

    static Connection con;
    static Statement stmt;
    static PreparedStatement preStmt;
    ComboBox db_tables_cb;
    TextArea status;

    public static ComboBox show_databases() throws SQLException {
        ComboBox cb = new ComboBox();
        stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("show databases;");
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();
        while (rs.next()) {
            String columnValue = rs.getString(1);
            cb.getItems().add(columnValue);
        }
        return cb;
    }

    public static ComboBox show_tables() throws SQLException {
        ComboBox cb = new ComboBox();
        stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("show tables;");
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();
        while (rs.next()) {
            String columnValue = rs.getString(1);
            cb.getItems().add(columnValue);
        }
        return cb;
    }

    public static String show_table_string() throws SQLException {
        String str = "";
        stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("show tables;");
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();
        while (rs.next()) {
            String columnValue = rs.getString(1);
            str += columnValue + "\n";
        }
        return str;
    }

    public static String select_table(String name) throws SQLException {
        ResultSet rs = stmt.executeQuery("select * from " + name + ";");
        return printResultStr(rs);
    }

    public static String connectToDB() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306", "root", "root");
            return "Connect!";
//            Statement stmt = con.createStatement();
//
//            stmt.executeQuery("use studentdb;");
//            ResultSet rs = stmt.executeQuery("show tables;");
//            printResult(rs);
//
//            String query = "delete from class101 where gpa > 0 ?";
//            PreparedStatement preparedStmt = con.prepareStatement(query);
//            preparedStmt.setInt(1, 3);
//            preparedStmt.execute();
//
//            rs = stmt.executeQuery("select * from class101 where gpa<3;");
//            printResult(rs);
//            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            return "Error";
        }
    }

    public static void printResult(ResultSet rs) throws SQLException {
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();
        while (rs.next()) {
            for (int i = 1; i <= columnsNumber; i++) {
                if (i > 1) {
                    System.out.print("| |");
                }
                String columnValue = rs.getString(i);
                System.out.print(rsmd.getColumnName(i) + " = " + columnValue);
            }
            System.out.println("");
        }
    }

    public static String[] printColNameArr(ResultSet rs) throws SQLException {
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();
        String[] str = new String[columnsNumber];
        System.out.println(columnsNumber);
        for (int i = 1; i <= columnsNumber; i++) {
            str[i - 1] = rsmd.getColumnName(i);
            System.out.println(rsmd.getColumnTypeName(i));
        }
        return str;
    }

    public static String[] printColTypeArr(ResultSet rs) throws SQLException {
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();
        String[] str = new String[columnsNumber];
        for (int i = 1; i <= columnsNumber; i++) {
            str[i - 1] = rsmd.getColumnTypeName(i);
        }
        return str;
    }

    public static String printResultStr(ResultSet rs) throws SQLException {
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnsNumber = rsmd.getColumnCount();
        String str = "";
        while (rs.next()) {
            for (int i = 1; i <= columnsNumber; i++) {
                if (i > 1) {
                    str += "| |";
                }
                String columnValue = rs.getString(i);
                str += rsmd.getColumnName(i) + " = " + columnValue;
            }
            str += "\n";
        }
        return str;
    }

    @Override
    public void start(Stage primaryStage) throws FileNotFoundException, IOException, SQLException {

        BorderPane main_window = new BorderPane();
// Left Side Bar items
        VBox b_list = new VBox();

        b_list.setStyle(
                "-fx-background-color: #FFFFFF80;");
        b_list.setAlignment(Pos.CENTER);

        b_list.setSpacing(
                5.0);
        Button b_select = new Button("Select");
        Button b_insert = new Button("Insert");
        Button b_update = new Button("Update");
        Button b_delete = new Button("Delete");

        b_select.setFont(Font.font(24));
        b_insert.setFont(Font.font(24));
        b_update.setFont(Font.font(24));
        b_delete.setFont(Font.font(24));

        b_list.getChildren()
                .addAll(b_select, b_insert, b_update, b_delete);
        main_window.setLeft(b_list);

        b_select.setOnAction((ActionEvent event) -> {
            try {
                VBox cond_VBox = new VBox();
                cond_VBox.setSpacing(5);
                VBox cond_VBox_cb = new VBox();
                cond_VBox_cb.setSpacing(5);
                final ObservableList<String> strings = FXCollections.observableArrayList();
                final ObservableList<String> stringsType = FXCollections.observableArrayList();
                final ObservableList<String> operators = FXCollections.observableArrayList();
                operators.addAll("=", "!=", ">", ">=", "<", "<=");
                ResultSet rs = stmt.executeQuery("select * from " + db_tables_cb.getValue() + ";");
                String[] str = printColNameArr(rs);
                String[] str_type = printColTypeArr(rs);
                for (int i = 0; i < str.length; i++) {
                    strings.add(str[i]);
                    stringsType.add(str_type[i]);
                    cond_VBox.getChildren().add(new TextField());
                    ComboBox a = new ComboBox(operators);
                    a.getSelectionModel().selectFirst();
                    cond_VBox_cb.getChildren().add(a);
                }
                final CheckListView<String> checkListViewCol = new CheckListView<>(strings);
                final CheckListView<String> checkListViewColType = new CheckListView<>(strings);

                Button show_btn = new Button("Show");
                show_btn.setFont(Font.font(18));
                show_btn.setOnAction(((ActionEvent event2) -> {
                    String qry = "select ";
                    ObservableList<String> checkCol = checkListViewCol.getCheckModel().getCheckedItems();
                    ObservableList<Integer> checkCol_where = checkListViewColType.getCheckModel().getCheckedIndices();
                    if (checkCol.size() == str.length || checkCol.size() == 0) {
                        qry += "* ";
                    } else {
                        for (int i = 0; i < checkCol.size(); i++) {
                            if (i == 0) {
                                qry += checkCol.get(i);
                            } else {
                                qry += "," + checkCol.get(i);
                            }
                        }
                    }
                    qry += " from " + db_tables_cb.getValue();

                    if (checkCol_where.size() != 0) {
                        qry += " where ";
                        for (int i = 0; i < checkCol_where.size(); i++) {
                            if (i != 0) {
                                qry += " and ";
                            }
                            int index = checkCol_where.get(i);
                            String o = (String) ((ComboBox) cond_VBox_cb.getChildren().get(index)).getValue();
                            String v = (String) ((TextField) cond_VBox.getChildren().get(index)).getText();

                            String type = stringsType.get(index);
                            if (type.contains("CHAR")) {
                                qry += strings.get(index) + " " + o + " \"" + v + "\"";
                            } else {
                                qry += strings.get(index) + " " + o + " " + v;
                            }
                        }
                    }
                    qry += ';';
                    try {

                        status.setText(qry + "\n" + printResultStr(stmt.executeQuery(qry)));
                    } catch (SQLException ex) {
                        Logger.getLogger(Visualizer.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }));

                Label ColView_label = new Label("Colums to View");
                Label Conditions_label = new Label("Conditions to be applied");
                ColView_label.setFont(Font.font(18));
                Conditions_label.setFont(Font.font(18));

                FlowPane select_FlowPane = new FlowPane();
                select_FlowPane.setHgap(20);
                select_FlowPane.getChildren().addAll(ColView_label, checkListViewCol, Conditions_label, checkListViewColType, cond_VBox_cb, cond_VBox, show_btn);
                main_window.setCenter(select_FlowPane);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

//        -- EXAMPLES
//DELETE FROM class101
//  -- Delete ALL rows from the table class101! Beware that there is NO UNDO!
//DELETE FROM class101 WHERE id = 33
//  -- Delete rows that meet the criteria.
        b_delete.setOnAction((ActionEvent event) -> {
            try {
                VBox cond_VBox = new VBox();
                cond_VBox.setSpacing(5);
                VBox cond_VBox_cb = new VBox();
                cond_VBox_cb.setSpacing(5);
                final ObservableList<String> strings = FXCollections.observableArrayList();
                final ObservableList<String> stringsType = FXCollections.observableArrayList();
                final ObservableList<String> operators = FXCollections.observableArrayList();
                operators.addAll("=", "!=", ">", ">=", "<", "<=");
                ResultSet rs = stmt.executeQuery("select * from " + db_tables_cb.getValue() + ";");
                String[] str = printColNameArr(rs);
                String[] str_type = printColTypeArr(rs);
                for (int i = 0; i < str.length; i++) {
                    strings.add(str[i]);
                    stringsType.add(str_type[i]);
                    cond_VBox.getChildren().add(new TextField());
                    ComboBox a = new ComboBox(operators);
                    a.getSelectionModel().selectFirst();
                    cond_VBox_cb.getChildren().add(a);
                }
                final CheckListView<String> checkListViewCol = new CheckListView<>(strings);

                Button show_btn = new Button("Delete");
                show_btn.setFont(Font.font(18));
                show_btn.setOnAction(((ActionEvent event2) -> {
                    String qry = "delete from " + db_tables_cb.getValue();
                    ObservableList<Integer> checkCol = checkListViewCol.getCheckModel().getCheckedIndices();

                    if (checkCol.size() != 0) {
                        qry += " where ";
                        for (int i = 0; i < checkCol.size(); i++) {
                            if (i != 0) {
                                qry += " and ";
                            }
                            int index = checkCol.get(i);
                            String o = (String) ((ComboBox) cond_VBox_cb.getChildren().get(index)).getValue();
                            String v = (String) ((TextField) cond_VBox.getChildren().get(index)).getText();
                            qry += strings.get(index) + " " + o + " " + v;
                        }
                    }
                    qry += ';';
                    try {
                        System.err.println(qry);
                        status.setText(qry + "\nDeleted items : " + stmt.executeUpdate(qry));

                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }

                }));

                Label Conditions_label = new Label("Delete considering the following conditions");
                Conditions_label.setFont(Font.font(18));

                FlowPane select_FlowPane = new FlowPane();
                select_FlowPane.setHgap(20);
                select_FlowPane.getChildren().addAll(Conditions_label, checkListViewCol, cond_VBox_cb, cond_VBox, show_btn);
                main_window.setCenter(select_FlowPane);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        b_insert.setOnAction((ActionEvent event) -> {
            try {
                VBox cond_VBox = new VBox();
                cond_VBox.setSpacing(5);

                final ObservableList<String> strings = FXCollections.observableArrayList();
                final ObservableList<String> stringsType = FXCollections.observableArrayList();

                ResultSet rs = stmt.executeQuery("select * from " + db_tables_cb.getValue() + ";");
                String[] str = printColNameArr(rs);
                String[] str_type = printColTypeArr(rs);
                for (int i = 0; i < str.length; i++) {
                    strings.add(str[i]);
                    stringsType.add(str_type[i]);
                    cond_VBox.getChildren().add(new TextField());

                }
                final CheckListView<String> checkListViewCol = new CheckListView<>(strings);

                Button show_btn = new Button("Insert");
                show_btn.setFont(Font.font(18));
                show_btn.setOnAction(((ActionEvent event2) -> {
                    String qry = "insert into " + db_tables_cb.getValue();
                    ObservableList<Integer> checkCol = checkListViewCol.getCheckModel().getCheckedIndices();

                    if (checkCol.size() == 0 || checkCol.size() == strings.size()) {
                        qry += " values (";
                        for (int i = 0; i < strings.size(); i++) {
                            if (i != 0) {
                                qry += ",";
                            }
                            String v = (String) ((TextField) cond_VBox.getChildren().get(i)).getText();
                            if (stringsType.get(i).contains("CHAR")) {
                                qry += "\"" + v + "\"";
                            } else {
                                qry += v;
                            }
                        }
                        qry += ")";
                    } else {
                        qry += "(";
                        for (int i = 0; i < checkCol.size(); i++) {
                            if (i != 0) {
                                qry += ",";
                            }
                            int index = checkCol.get(i);
                            String o = (String) strings.get(index);
                            qry += o;
                        }
                        qry += ")";

                        qry += " values (";
                        for (int i = 0; i < checkCol.size(); i++) {
                            if (i != 0) {
                                qry += ",";
                            }
                            int index = checkCol.get(i);
                            String v = (String) ((TextField) cond_VBox.getChildren().get(index)).getText();
                            if (stringsType.get(index).contains("CHAR")) {
                                qry += "\"" + v + "\"";
                            } else {
                                qry += v;
                            }
                        }
                        qry += ")";

                    }
                    qry += ';';
                    try {
                        System.err.println(qry);
                        status.setText(qry + "\nAdded items : " + stmt.executeUpdate(qry));

                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }

                }));

                Label Conditions_label = new Label("insert into the following Colums");
                Conditions_label.setFont(Font.font(18));

                FlowPane select_FlowPane = new FlowPane();
                select_FlowPane.setHgap(20);
                select_FlowPane.getChildren().addAll(Conditions_label, checkListViewCol, cond_VBox, show_btn);
                main_window.setCenter(select_FlowPane);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

//        UPDATE class101 SET gpa = 5.0                                  -- ALL rows
//UPDATE class101 SET gpa = gpa + 1.0 WHERE name = 'Tan Ah Teck' -- Selected rows
        b_update.setOnAction((ActionEvent event) -> {
            try {
                VBox val_VBox = new VBox();
                val_VBox.setSpacing(5);
                VBox cond_VBox = new VBox();
                cond_VBox.setSpacing(5);
                VBox cond_VBox_cb = new VBox();
                cond_VBox_cb.setSpacing(5);
                VBox val_cond_VBox = new VBox();
                val_cond_VBox.setSpacing(5);
                final ObservableList<String> strings = FXCollections.observableArrayList();
                final ObservableList<String> stringsType = FXCollections.observableArrayList();
                final ObservableList<String> operators = FXCollections.observableArrayList();
                operators.addAll("=", "!=", ">", ">=", "<", "<=");
                ResultSet rs = stmt.executeQuery("select * from " + db_tables_cb.getValue() + ";");
                String[] str = printColNameArr(rs);
                String[] str_type = printColTypeArr(rs);
                for (int i = 0; i < str.length; i++) {
                    strings.add(str[i]);
                    stringsType.add(str_type[i]);
                    cond_VBox.getChildren().add(new TextField());
                    val_VBox.getChildren().add(new TextField());
                    val_cond_VBox.getChildren().add(new TextField());
                    ComboBox a = new ComboBox(operators);
                    a.getSelectionModel().selectFirst();
                    cond_VBox_cb.getChildren().add(a);
                }
                final CheckListView<String> checkListViewCol = new CheckListView<>(strings);
                final CheckListView<String> checkListViewColType = new CheckListView<>(strings);

                Button show_btn = new Button("Update");
                show_btn.setFont(Font.font(18));
                show_btn.setOnAction(((ActionEvent event2) -> {
                    String qry = "update " + db_tables_cb.getValue() + " set ";
                    ObservableList<String> checkCol = checkListViewCol.getCheckModel().getCheckedItems();
                    ObservableList<Integer> checkColIndex = checkListViewCol.getCheckModel().getCheckedIndices();
                    ObservableList<Integer> checkCol_where = checkListViewColType.getCheckModel().getCheckedIndices();
                    if (checkCol.size() > 0) {
                        for (int i = 0; i < checkCol.size(); i++) {
                            int index = checkColIndex.get(i);
                            String t = stringsType.get(index);
                            String v = ((TextField) cond_VBox.getChildren().get(index)).getText();
                            if (i == 0) {
                                if (t.contains("CHAR")) {
                                    qry += checkCol.get(i) + " = \"" + v + "\"";
                                } else {
                                    qry += checkCol.get(i) + " = " + v;
                                }
                            } else {
                                if (t.contains("CHAR")) {
                                    qry += "," + checkCol.get(i) + " = \"" + v + "\"";
                                } else {
                                    qry += "," + checkCol.get(i) + " = " + v;
                                }
                            }
                        }
                    }

                    if (checkCol_where.size() != 0) {
                        qry += " where ";
                        for (int i = 0; i < checkCol_where.size(); i++) {
                            if (i != 0) {
                                qry += " and ";
                            }
                            int index = checkCol_where.get(i);
                            String o = (String) ((ComboBox) cond_VBox_cb.getChildren().get(index)).getValue();
                            String v = (String) ((TextField) val_cond_VBox.getChildren().get(index)).getText();
                            String type = stringsType.get(index);
                            if (type.contains("CHAR")) {
                                qry += strings.get(index) + " " + o + " \"" + v + "\"";
                            } else {
                                qry += strings.get(index) + " " + o + " " + v;
                            }
                        }
                    }
                    qry += ';';
                    try {
                        System.out.println(qry);
                        status.setText(qry + "\n" + stmt.executeUpdate(qry));
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }));

                Label ColView_label = new Label("Colums to Set");
                Label Conditions_label = new Label("Conditions to be considered");
                ColView_label.setFont(Font.font(18));
                Conditions_label.setFont(Font.font(18));

                FlowPane select_FlowPane = new FlowPane();
                select_FlowPane.setHgap(20);
                select_FlowPane.getChildren().addAll(ColView_label, checkListViewCol, cond_VBox, Conditions_label, checkListViewColType, cond_VBox_cb, val_cond_VBox, show_btn);
                main_window.setCenter(select_FlowPane);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

// Buttom Side Bar items
        status = new TextArea(connectToDB());

        status.setEditable(
                false);
        status.setFont(Font.font(24));
        status.setStyle(
                "-fx-control-inner-background: #000000;");
        main_window.setBottom(status);

// Top Side Bar items
        Label database_label = new Label("Database");
        ComboBox db_name_cb = show_databases();
        db_name_cb.getSelectionModel().selectFirst();

        stmt.executeQuery("use " + db_name_cb.getValue() + ";");
        status.setText("Using " + db_name_cb.getValue());

        Button use_btn = new Button("Use");
        use_btn.setOnAction((ActionEvent event) -> {
            if (db_name_cb.getValue() != null && !db_name_cb.getValue().toString().isEmpty()) {
                try {
                    stmt.executeQuery("use " + db_name_cb.getValue() + ";");
                    status.setText("Using " + db_name_cb.getValue());
//                    status.setText(status.getText() + "\nUsing " + db_name$.getValue());
                    db_tables_cb.getItems().clear();
                    db_tables_cb.getItems().addAll(show_tables().getItems());
                    db_tables_cb.getSelectionModel().selectFirst();
                } catch (SQLException ex) {
                    System.err.println("Error Using " + db_name_cb.getValue());
                }
            }
        });
        db_tables_cb = show_tables();
        db_tables_cb.getSelectionModel().selectFirst();
        Button show_table_btn = new Button("Show Table");
        show_table_btn.setOnAction((ActionEvent event) -> {
            if (db_tables_cb.getValue() != null && !db_tables_cb.getValue().toString().isEmpty()) {
                try {
                    status.setText(select_table((String) db_tables_cb.getValue()));
//                    status.setText(status.getText() + ShowTables());
                } catch (SQLException ex) {
                    System.err.println("Error Showing tables ");
                }
            }

        });
        Label select_table_label = new Label("Select Table");

        Button show_tables_btn = new Button("Show Tables");
        show_tables_btn.setOnAction((ActionEvent event) -> {
            if (db_name_cb.getValue() != null && !db_name_cb.getValue().toString().isEmpty()) {
                try {
                    status.setText(show_table_string());
//                    status.setText(status.getText() + ShowTables());
                } catch (SQLException ex) {
                    System.err.println("Error Showing tables ");
                }
            }

        });

        database_label.setFont(Font.font(18));
        select_table_label.setFont(Font.font(18));
        show_tables_btn.setFont(Font.font(18));
        show_table_btn.setFont(Font.font(18));
        use_btn.setFont(Font.font(18));

        FlowPane flow = new FlowPane();
        flow.getChildren()
                .addAll(database_label, db_name_cb, use_btn, show_tables_btn, select_table_label, db_tables_cb, show_table_btn);
        flow.setHgap(
                30.0);
        main_window.setTop(flow);

//================================================================================
        Scene scene = new Scene(main_window);
        Screen screen = Screen.getPrimary();
        Rectangle2D bounds = screen.getVisualBounds();

        primaryStage.setX(bounds.getMinX());
        primaryStage.setY(bounds.getMinY());
        primaryStage.setWidth(bounds.getWidth());
        primaryStage.setHeight(bounds.getHeight());
        primaryStage.setTitle(
                "Visual Database");
        primaryStage.setScene(scene);

        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
        //D:\GUC_Courses\Semester 10\Visual Programing\Projects\mini-project-3\test4.txt
    }

}
